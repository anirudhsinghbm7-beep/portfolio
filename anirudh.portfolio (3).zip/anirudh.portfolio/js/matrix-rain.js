/* ==========================================================================
   HACKER THEME - MATRIX DIGITAL RAIN CANVAS
   Authentic falling green code stream with high performance & depth
   ========================================================================== */

(function () {
  const canvas = document.getElementById('bg-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  let width = 0;
  let height = 0;
  const fontSize = 16;
  let columns = 0;
  let drops = [];
  let speeds = [];
  let charArrays = [];
  let active = true;

  // Authentic Matrix Character Set: Katakana, Binary, Hex, Latin, Operators
  const matrixChars = 
    'ｦｱｳｴｵｶｷｹｹｺｻｼｽｾｿﾀﾂﾃﾅﾆﾇﾈﾊﾋﾎﾏﾐﾑﾒﾓﾔﾕﾗﾘﾜ' +
    '0123456789' +
    'ABCDEF' +
    ':・."=*+-<>¦|_01';

  const mouse = {
    x: -1000,
    y: -1000,
    radius: 120
  };

  function init() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
    columns = Math.floor(width / fontSize);

    drops = [];
    speeds = [];
    charArrays = [];

    for (let i = 0; i < columns; i++) {
      // Random starting positions so they fall staggered
      drops[i] = Math.floor(Math.random() * -50);
      speeds[i] = Math.random() * 0.6 + 0.7; // Variable speeds
      charArrays[i] = matrixChars[Math.floor(Math.random() * matrixChars.length)];
    }

    // Initial background clear
    ctx.fillStyle = '#07090e';
    ctx.fillRect(0, 0, width, height);
  }

  window.addEventListener('resize', () => {
    init();
  });

  window.addEventListener('mousemove', (e) => {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
  });

  window.addEventListener('mouseout', () => {
    mouse.x = -1000;
    mouse.y = -1000;
  });

  init();

  let lastFrameTime = 0;
  const fpsInterval = 1000 / 30; // 30fps gives authentic terminal feel & extreme efficiency

  function draw(currentTime) {
    if (!active) {
      requestAnimationFrame(draw);
      return;
    }

    requestAnimationFrame(draw);

    const elapsed = currentTime - lastFrameTime;
    if (elapsed < fpsInterval) return;
    lastFrameTime = currentTime - (elapsed % fpsInterval);

    // Translucent black rectangle creates the trailing fade effect
    ctx.fillStyle = 'rgba(7, 9, 14, 0.085)';
    ctx.fillRect(0, 0, width, height);

    ctx.font = `600 ${fontSize}px "JetBrains Mono", "Courier New", monospace`;

    for (let i = 0; i < drops.length; i++) {
      const x = i * fontSize;
      const y = drops[i] * fontSize;

      // Pick a random character
      const char = matrixChars[Math.floor(Math.random() * matrixChars.length)];

      // Check distance to mouse
      const distToMouse = Math.hypot(x - mouse.x, y - mouse.y);
      const isNearMouse = distToMouse < mouse.radius;

      if (y > 0 && y < height + fontSize) {
        if (isNearMouse) {
          // Extra bright neon glow near cursor
          ctx.fillStyle = '#ffffff';
          ctx.shadowColor = '#00ff66';
          ctx.shadowBlur = 12;
          ctx.fillText(char, x, y);
          ctx.shadowBlur = 0;
        } else {
          // Head of the stream is bright white/light-green
          ctx.fillStyle = '#d1fae5';
          ctx.shadowColor = '#00ff66';
          ctx.shadowBlur = 6;
          ctx.fillText(char, x, y);
          ctx.shadowBlur = 0;

          // Trail character just behind the head
          if (drops[i] > 1) {
            const prevChar = matrixChars[Math.floor(Math.random() * matrixChars.length)];
            ctx.fillStyle = '#00ff66';
            ctx.fillText(prevChar, x, (drops[i] - 1) * fontSize);
          }

          // Occasional darker green character further up
          if (drops[i] > 3 && Math.random() > 0.5) {
            const olderChar = matrixChars[Math.floor(Math.random() * matrixChars.length)];
            ctx.fillStyle = '#059669';
            ctx.fillText(olderChar, x, (drops[i] - 3) * fontSize);
          }
        }
      }

      // Reset when drop reaches bottom
      if (y > height && Math.random() > 0.975) {
        drops[i] = 0;
        speeds[i] = Math.random() * 0.6 + 0.7;
      }

      // Advance drop position with variable speed
      drops[i] += speeds[i];
    }
  }

  requestAnimationFrame(draw);

  // Expose toggle control globally
  window.toggleMatrixRain = function (enable) {
    if (enable !== undefined) {
      active = enable;
    } else {
      active = !active;
    }
    return active;
  };
})();
