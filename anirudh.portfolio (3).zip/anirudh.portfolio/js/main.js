/* ==========================================================================
   ANIRUDH SINGH B M - PORTFOLIO CORE INTERACTION LOGIC
   Cinematic experience, interactive storytelling, and smooth animations
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* --------------------------------------------------------------------------
     1. PRELOADER & INITIALIZATION SEQUENCE
     -------------------------------------------------------------------------- */
  const preloader = document.getElementById('preloader');
  const loaderFill = document.getElementById('loader-fill');
  const loaderLines = document.querySelectorAll('.loader-line');

  let progress = 0;
  const progressInterval = setInterval(() => {
    progress += Math.floor(Math.random() * 12) + 8;
    if (progress > 100) progress = 100;
    if (loaderFill) loaderFill.style.width = `${progress}%`;

    if (progress >= 100) {
      clearInterval(progressInterval);
      setTimeout(() => {
        if (preloader) {
          preloader.classList.add('loaded');
          setTimeout(() => preloader.remove(), 700);
        }
      }, 350);
    }
  }, 120);

  /* --------------------------------------------------------------------------
     2. HACKER HUD CURSOR & TELEMETRY
     -------------------------------------------------------------------------- */
  const cursorDot = document.querySelector('.custom-cursor-dot');
  const cursorRing = document.querySelector('.custom-cursor-ring');
  const cursorHud = document.getElementById('cursor-hud-coords');

  if (cursorDot && cursorRing) {
    let mouseX = -100, mouseY = -100;
    let ringX = -100, ringY = -100;
    let isHovering = false;

    window.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      cursorDot.style.left = `${mouseX}px`;
      cursorDot.style.top = `${mouseY}px`;

      if (cursorHud && !isHovering) {
        cursorHud.textContent = `LOC // ${mouseX}:${mouseY}`;
      }
    });

    const renderCursorRing = () => {
      ringX += (mouseX - ringX) * 0.22;
      ringY += (mouseY - ringY) * 0.22;
      cursorRing.style.left = `${ringX}px`;
      cursorRing.style.top = `${ringY}px`;
      if (cursorHud) {
        cursorHud.style.left = `${ringX}px`;
        cursorHud.style.top = `${ringY}px`;
      }
      requestAnimationFrame(renderCursorRing);
    };
    requestAnimationFrame(renderCursorRing);

    // Click cyber ripple shockwave
    window.addEventListener('click', (e) => {
      const ripple = document.createElement('div');
      ripple.className = 'cursor-click-ripple';
      ripple.style.left = `${e.clientX}px`;
      ripple.style.top = `${e.clientY}px`;
      document.body.appendChild(ripple);
      setTimeout(() => ripple.remove(), 550);
    });

    // Hover effect on links, buttons & interactive cards
    const interactiveElements = document.querySelectorAll('a, button, .timeline-node, .mode-btn, .term-cmd-pill, .skill-card, .weather-mode-btn, .project-feature-card, .component-card, .growth-insight-box');
    interactiveElements.forEach(el => {
      el.addEventListener('mouseenter', () => {
        isHovering = true;
        document.body.classList.add('cursor-hover');
        if (cursorHud) cursorHud.textContent = 'TARGET // LOCKED';
      });
      el.addEventListener('mouseleave', () => {
        isHovering = false;
        document.body.classList.remove('cursor-hover');
        if (cursorHud) cursorHud.textContent = `LOC // ${mouseX}:${mouseY}`;
      });
    });
  }

  /* --------------------------------------------------------------------------
     3. STICKY NAVBAR & MOBILE MENU
     -------------------------------------------------------------------------- */
  const navbar = document.getElementById('navbar');
  const navToggle = document.getElementById('nav-toggle');
  const navMenu = document.getElementById('nav-menu');
  const navLinks = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      navToggle.classList.toggle('open');
      navMenu.classList.toggle('open');
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        navToggle.classList.remove('open');
        navMenu.classList.remove('open');
      });
    });
  }

  // Hacker Matrix Rain Control Button
  const matrixToggleBtn = document.getElementById('btn-toggle-matrix');
  if (matrixToggleBtn) {
    matrixToggleBtn.addEventListener('click', () => {
      if (typeof window.toggleMatrixRain === 'function') {
        const isRunning = window.toggleMatrixRain();
        if (isRunning) {
          matrixToggleBtn.classList.remove('paused');
          matrixToggleBtn.querySelector('.matrix-btn-text').textContent = 'MATRIX RAIN';
        } else {
          matrixToggleBtn.classList.add('paused');
          matrixToggleBtn.querySelector('.matrix-btn-text').textContent = 'RAIN PAUSED';
        }
      }
    });
  }

  /* --------------------------------------------------------------------------
     4. NAVIGATION SCROLLSPY
     -------------------------------------------------------------------------- */
  const sections = document.querySelectorAll('section[id]');
  const observeSection = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navLinks.forEach(link => {
          if (link.getAttribute('href') === `#${id}`) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    });
  }, { threshold: 0.25 });

  sections.forEach(sec => observeSection.observe(sec));

  /* --------------------------------------------------------------------------
     5. SECTION 1: GAMING RIG SIMULATOR (Gamer vs Curiosity Mode)
     -------------------------------------------------------------------------- */
  const modeGamerBtn = document.getElementById('btn-mode-gamer');
  const modeCuriousBtn = document.getElementById('btn-mode-curiosity');
  const gamerScreen = document.getElementById('screen-gamer');
  const curiosityScreen = document.getElementById('screen-curiosity');

  if (modeGamerBtn && modeCuriousBtn && gamerScreen && curiosityScreen) {
    modeGamerBtn.addEventListener('click', () => {
      modeGamerBtn.classList.add('active');
      modeCuriousBtn.classList.remove('active');
      gamerScreen.classList.remove('hidden');
      curiosityScreen.classList.add('hidden');
    });

    modeCuriousBtn.addEventListener('click', () => {
      modeCuriousBtn.classList.add('active');
      modeGamerBtn.classList.remove('active');
      curiosityScreen.classList.remove('hidden');
      gamerScreen.classList.add('hidden');
    });
  }

  /* --------------------------------------------------------------------------
     6. SECTION 2: INTERACTIVE ENGINEERING TIMELINE
     -------------------------------------------------------------------------- */
  const timelineNodes = document.querySelectorAll('.timeline-node');
  const timelineProgress = document.getElementById('timeline-progress-bar');
  const storyTag = document.getElementById('timeline-story-tag');
  const storyHeading = document.getElementById('timeline-story-heading');
  const storyBody = document.getElementById('timeline-story-body');

  const timelineData = [
    {
      tag: 'STAGE 01 // 10TH GRADE',
      title: 'The First Gaming Desktop',
      body: 'Getting my first gaming desktop in 10th grade opened the door to technology. Initially, it was just about running games and playing with friends, but it quietly sparked an obsession with the machine itself.',
      progress: '10%'
    },
    {
      tag: 'STAGE 02 // CURIOSITY',
      title: 'Peeking Behind the Screen',
      body: 'I began asking questions: How does software actually execute? How do 3D scenes communicate with the hardware? What is going on behind the monitor? The transition from passive consumer to curious observer began here.',
      progress: '28%'
    },
    {
      tag: 'STAGE 03 // ENGINEERING',
      title: 'Adichunchungiri Institute of Technology',
      body: 'Choosing Computer Science Engineering gave that scattered curiosity a clear academic and practical direction. Currently pursuing my engineering degree with an expected graduation in 2029.',
      progress: '48%'
    },
    {
      tag: 'STAGE 04 // CODING',
      title: 'Mastering the Fundamentals',
      body: 'Stepping into code wasn’t magic; it was understanding logic, data structures, and syntax. Writing programs in C and C++, understanding object-oriented principles in Java, and automating with Python.',
      progress: '66%'
    },
    {
      tag: 'STAGE 05 // PROJECTS',
      title: 'Building Real Systems',
      body: 'Moving beyond textbooks into active building: wiring microcontrollers like the ESP32 for the IoT Fire Alarm System, and connecting interfaces to meteorological APIs for the Weather Forecast app.',
      progress: '84%'
    },
    {
      tag: 'STAGE 06 // CYBERSECURITY',
      title: 'Exploring Protection & Resilience',
      body: 'Learning how code is built immediately brought up a new question: How is it defended? Now laying foundations in cybersecurity, network architecture, and defensive engineering.',
      progress: '100%'
    }
  ];

  timelineNodes.forEach((node, idx) => {
    node.addEventListener('click', () => {
      timelineNodes.forEach(n => n.classList.remove('active'));
      node.classList.add('active');

      const data = timelineData[idx];
      if (data) {
        if (timelineProgress) timelineProgress.style.width = data.progress;
        if (storyTag) storyTag.textContent = data.tag;
        if (storyHeading) storyHeading.textContent = data.title;
        if (storyBody) storyBody.textContent = data.body;
      }
    });
  });

  /* --------------------------------------------------------------------------
     7. SECTION 4: INTERACTIVE CODE TERMINAL
     -------------------------------------------------------------------------- */
  const terminalTabs = document.querySelectorAll('.term-cmd-pill');
  const terminalBody = document.getElementById('terminal-content-area');

  const terminalScripts = {
    c: {
      cmd: 'gcc project.c -o system_app && ./system_app',
      output: [
        'Compiling memory-model.c...',
        '[OK] Compilation successful. Zero warnings.',
        'Executing system_app binary...',
        '-> Initializing memory pointer table',
        '-> Hardware register check: PASSED',
        'Process completed with exit code 0.'
      ]
    },
    java: {
      cmd: 'java Main.java',
      output: [
        'Loading JVM Runtime (OpenJDK 21)...',
        'Compiling OOP Class Hierarchy...',
        '[OK] Object instances allocated.',
        '-> Initializing Core Application Service',
        '-> Thread pool online. Ready for events.',
        'Application terminated gracefully.'
      ]
    },
    python: {
      cmd: 'python weather.py --location="Karnataka"',
      output: [
        'Importing requests, json, datetime...',
        'Connecting to live meteorological endpoint...',
        '[OK] HTTP 200 OK received.',
        '-> Temperature: 28.4°C | Humidity: 65% | Wind: 12 km/h',
        '-> Forecast cached locally for offline telemetry.',
        'Telemetry stream synced.'
      ]
    },
    security: {
      cmd: './security-lab --scan-perimeter',
      output: [
        'Starting passive packet inspection...',
        'Binding listener to network interface eth0...',
        '[SCAN] Inspecting inbound header packets...',
        '-> Port 80/443: Filtered & Monitored',
        '-> Firewall Integrity: Active (0 anomalies)',
        'Defensive perimeter baseline established.'
      ]
    }
  };

  let activeTabKey = 'c';
  let typingTimer = null;

  function renderTerminalContent(key) {
    if (!terminalBody) return;
    clearTimeout(typingTimer);
    const data = terminalScripts[key];
    if (!data) return;

    terminalBody.innerHTML = `
      <div style="margin-bottom: 8px;">
        <span class="terminal-prompt">anirudh@engine:~$</span>
        <span id="typed-command" style="color: #ffffff; font-weight: 600;"></span>
        <span class="terminal-cursor"></span>
      </div>
      <div id="command-output-lines" style="color: #94a3b8; font-size: 0.82rem;"></div>
    `;

    const cmdTarget = document.getElementById('typed-command');
    const outTarget = document.getElementById('command-output-lines');
    let charIdx = 0;

    function typeChar() {
      if (charIdx < data.cmd.length) {
        cmdTarget.textContent += data.cmd.charAt(charIdx);
        charIdx++;
        typingTimer = setTimeout(typeChar, 28);
      } else {
        // Render output lines with subtle delay
        typingTimer = setTimeout(() => {
          outTarget.innerHTML = data.output.map(line => {
            let color = '#cbd5e1';
            if (line.includes('[OK]')) color = '#34d399';
            if (line.includes('->')) color = '#38bdf8';
            if (line.includes('[SCAN]')) color = '#f59e0b';
            return `<div style="margin-top: 4px; color: ${color};">${line}</div>`;
          }).join('');
        }, 150);
      }
    }

    typeChar();
  }

  terminalTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      terminalTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      activeTabKey = tab.getAttribute('data-lang');
      renderTerminalContent(activeTabKey);
    });
  });

  // Initial terminal render
  renderTerminalContent('c');

  /* --------------------------------------------------------------------------
     8. SECTION 5: INTERACTIVE PROJECT SIMULATORS
     -------------------------------------------------------------------------- */
  // Project 01: IoT Fire Alarm System
  const btnTriggerFire = document.getElementById('btn-simulate-fire');
  const fireStatusBadge = document.getElementById('iot-status-indicator');
  const flameCard = document.getElementById('comp-ir-sensor');
  const buzzerCard = document.getElementById('comp-buzzer');
  const blynkCard = document.getElementById('comp-blynk');

  let fireSimulated = false;

  if (btnTriggerFire) {
    btnTriggerFire.addEventListener('click', () => {
      fireSimulated = !fireSimulated;

      if (fireSimulated) {
        btnTriggerFire.textContent = 'Reset System to Normal';
        btnTriggerFire.style.background = 'rgba(16, 185, 129, 0.15)';
        btnTriggerFire.style.borderColor = '#10b981';
        btnTriggerFire.style.color = '#34d399';

        if (fireStatusBadge) {
          fireStatusBadge.innerHTML = '● ALERT: FLAME DETECTED';
          fireStatusBadge.classList.add('triggered');
        }
        if (flameCard) {
          flameCard.classList.add('active-flame');
          flameCard.querySelector('.comp-state').textContent = 'FLAME DETECTED (IR Spike)';
          flameCard.querySelector('.comp-state').style.color = '#ef4444';
        }
        if (buzzerCard) {
          buzzerCard.classList.add('active-flame');
          buzzerCard.querySelector('.comp-state').textContent = 'ACTIVE (85dB Pulsing)';
          buzzerCard.querySelector('.comp-state').style.color = '#ef4444';
        }
        if (blynkCard) {
          blynkCard.querySelector('.comp-state').textContent = 'ALERT PUSHED TO MOBILE';
          blynkCard.querySelector('.comp-state').style.color = '#f59e0b';
        }
      } else {
        btnTriggerFire.textContent = 'Simulate Flame / Heat Condition';
        btnTriggerFire.style.background = '';
        btnTriggerFire.style.borderColor = '';
        btnTriggerFire.style.color = '';

        if (fireStatusBadge) {
          fireStatusBadge.innerHTML = '● SYSTEM ARMED & SENSING';
          fireStatusBadge.classList.remove('triggered');
        }
        if (flameCard) {
          flameCard.classList.remove('active-flame');
          flameCard.querySelector('.comp-state').textContent = 'NORMAL (No Flame)';
          flameCard.querySelector('.comp-state').style.color = '#ffffff';
        }
        if (buzzerCard) {
          buzzerCard.classList.remove('active-flame');
          buzzerCard.querySelector('.comp-state').textContent = 'SILENT (Idle)';
          buzzerCard.querySelector('.comp-state').style.color = '#ffffff';
        }
        if (blynkCard) {
          blynkCard.querySelector('.comp-state').textContent = 'CONNECTED (Online)';
          blynkCard.querySelector('.comp-state').style.color = '#34d399';
        }
      }
    });
  }

  // Project 02: Weather Forecast Simulation
  const weatherBtns = document.querySelectorAll('.weather-mode-btn');
  const weatherTemp = document.getElementById('weather-temp-num');
  const weatherCond = document.getElementById('weather-cond-text');
  const weatherHumid = document.getElementById('weather-stat-humid');
  const weatherWind = document.getElementById('weather-stat-wind');
  const weatherBox = document.getElementById('weather-visual-box');

  const weatherPresets = {
    sunny: {
      temp: '29°C',
      cond: 'Clear Sky / Sunny',
      humid: '48%',
      wind: '8 km/h',
      bg: 'linear-gradient(180deg, rgba(234, 179, 8, 0.2) 0%, rgba(15, 23, 42, 0.6) 100%)'
    },
    rain: {
      temp: '21°C',
      cond: 'Monsoon Rain',
      humid: '92%',
      wind: '24 km/h',
      bg: 'linear-gradient(180deg, rgba(59, 130, 246, 0.25) 0%, rgba(15, 23, 42, 0.7) 100%)'
    },
    cloudy: {
      temp: '25°C',
      cond: 'Overcast & Breeze',
      humid: '70%',
      wind: '14 km/h',
      bg: 'linear-gradient(180deg, rgba(148, 163, 184, 0.2) 0%, rgba(15, 23, 42, 0.6) 100%)'
    }
  };

  weatherBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      weatherBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const mode = btn.getAttribute('data-weather');
      const data = weatherPresets[mode];
      if (data) {
        if (weatherTemp) weatherTemp.textContent = data.temp;
        if (weatherCond) weatherCond.textContent = data.cond;
        if (weatherHumid) weatherHumid.textContent = `Humidity: ${data.humid}`;
        if (weatherWind) weatherWind.textContent = `Wind: ${data.wind}`;
        if (weatherBox) weatherBox.style.background = data.bg;
      }
    });
  });

  /* --------------------------------------------------------------------------
     9. MODAL CONTROLS (Technical Details & Contact)
     -------------------------------------------------------------------------- */
  const openModal = (modalId) => {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  };

  const closeModal = (modalId) => {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('open');
      document.body.style.overflow = '';
    }
  };

  // Triggers
  document.querySelectorAll('[data-open-modal]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = btn.getAttribute('data-open-modal');
      openModal(targetId);
    });
  });

  document.querySelectorAll('[data-close-modal]').forEach(btn => {
    btn.addEventListener('click', () => {
      const parentModal = btn.closest('.modal-backdrop');
      if (parentModal) {
        parentModal.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
  });

  // Close when clicking outside modal container
  document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        backdrop.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
  });

  // ESC key closes modals
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-backdrop.open').forEach(m => {
        m.classList.remove('open');
      });
      document.body.style.overflow = '';
    }
  });

  /* --------------------------------------------------------------------------
     10. COPY EMAIL TO CLIPBOARD
     -------------------------------------------------------------------------- */
  const copyBtn = document.getElementById('btn-copy-email');
  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      const emailText = copyBtn.getAttribute('data-email') || 'anirudh.singhbm@example.com';
      navigator.clipboard.writeText(emailText).then(() => {
        const originalText = copyBtn.textContent;
        copyBtn.textContent = 'Copied!';
        copyBtn.style.background = '#10b981';
        copyBtn.style.color = '#000';
        setTimeout(() => {
          copyBtn.textContent = originalText;
          copyBtn.style.background = '';
          copyBtn.style.color = '';
        }, 2000);
      }).catch(err => {
        console.error('Copy failed:', err);
      });
    });
  }

});
