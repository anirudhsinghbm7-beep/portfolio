/* ==========================================================================
   CYBERSECURITY NETWORK & PACKET INSPECTION CANVAS
   Visualizes data flow, firewall perimeter & packet security analysis
   ========================================================================== */

(function () {
  const canvas = document.getElementById('cyber-network-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const triggerBtn = document.getElementById('trigger-packet-scan');
  const hudStatus = document.getElementById('hud-defense-status');

  let width, height;

  function resize() {
    const rect = canvas.getBoundingClientRect();
    width = canvas.width = rect.width * window.devicePixelRatio;
    height = canvas.height = rect.height * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
  }

  window.addEventListener('resize', resize);
  setTimeout(resize, 100);

  // Logical dimensions
  function getLogicalSize() {
    return {
      w: canvas.clientWidth,
      h: canvas.clientHeight
    };
  }

  // Network topology nodes
  const nodeDefs = [
    { id: 'client', label: 'CLIENT', xFactor: 0.15, yFactor: 0.5, color: '#38bdf8' },
    { id: 'firewall', label: 'FIREWALL / SHIELD', xFactor: 0.5, yFactor: 0.5, color: '#10b981' },
    { id: 'server', label: 'CORE BACKEND', xFactor: 0.85, yFactor: 0.35, color: '#8b5cf6' },
    { id: 'db', label: 'SECURE STORAGE', xFactor: 0.85, yFactor: 0.65, color: '#00e5ff' }
  ];

  let packets = [];

  class Packet {
    constructor(sourceId, targetId, status = 'inspecting') {
      this.sourceId = sourceId;
      this.targetId = targetId;
      this.progress = 0;
      this.speed = 0.015;
      this.status = status; // 'inspecting', 'verified', 'blocked'
    }

    update() {
      this.progress += this.speed;
      return this.progress < 1;
    }
  }

  // Periodic ambient packets
  setInterval(() => {
    if (packets.length < 5) {
      const targets = ['server', 'db'];
      const target = targets[Math.floor(Math.random() * targets.length)];
      packets.push(new Packet('client', 'firewall', 'inspecting'));
    }
  }, 1400);

  if (triggerBtn) {
    triggerBtn.addEventListener('click', () => {
      // Trigger a burst of inspected secure packets
      packets.push(new Packet('client', 'firewall', 'inspecting'));
      setTimeout(() => {
        packets.push(new Packet('firewall', 'server', 'verified'));
      }, 400);
      setTimeout(() => {
        packets.push(new Packet('firewall', 'db', 'verified'));
      }, 700);

      if (hudStatus) {
        hudStatus.textContent = 'PERIMETER SCAN: 0 THREATS DETECTED';
        hudStatus.style.color = '#34d399';
        setTimeout(() => {
          hudStatus.textContent = 'DEFENSE ACTIVE • MONITORING';
          hudStatus.style.color = '';
        }, 3000);
      }
    });
  }

  function getCoords(factorX, factorY, w, h) {
    return {
      x: w * factorX,
      y: h * factorY
    };
  }

  let frame = 0;

  function render() {
    frame++;
    const { w, h } = getLogicalSize();
    if (w === 0 || h === 0) {
      requestAnimationFrame(render);
      return;
    }

    ctx.clearRect(0, 0, w, h);

    // Node coordinates map
    const coords = {};
    nodeDefs.forEach(n => {
      coords[n.id] = getCoords(n.xFactor, n.yFactor, w, h);
    });

    // Draw connection pipes
    const links = [
      ['client', 'firewall'],
      ['firewall', 'server'],
      ['firewall', 'db']
    ];

    links.forEach(([from, to]) => {
      ctx.beginPath();
      ctx.moveTo(coords[from].x, coords[from].y);
      ctx.lineTo(coords[to].x, coords[to].y);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 4]);
      ctx.stroke();
      ctx.setLineDash([]);
    });

    // Update & draw packets
    for (let i = packets.length - 1; i >= 0; i--) {
      const p = packets[i];
      const start = coords[p.sourceId];
      const end = coords[p.targetId];

      if (!start || !end) {
        packets.splice(i, 1);
        continue;
      }

      const curX = start.x + (end.x - start.x) * p.progress;
      const curY = start.y + (end.y - start.y) * p.progress;

      ctx.beginPath();
      ctx.arc(curX, curY, 4, 0, Math.PI * 2);

      let color = 'rgba(56, 189, 248, 0.9)';
      if (p.status === 'verified') color = 'rgba(16, 185, 129, 0.9)';
      if (p.status === 'blocked') color = 'rgba(239, 68, 68, 0.9)';

      ctx.fillStyle = color;
      ctx.shadowColor = color;
      ctx.shadowBlur = 8;
      ctx.fill();
      ctx.shadowBlur = 0;

      if (!p.update()) {
        // If arrived at firewall, forward to server
        if (p.sourceId === 'client' && p.targetId === 'firewall') {
          packets.push(new Packet('firewall', Math.random() > 0.5 ? 'server' : 'db', 'verified'));
        }
        packets.splice(i, 1);
      }
    }

    // Draw Nodes
    nodeDefs.forEach(n => {
      const pos = coords[n.id];

      // Outer glowing pulse ring
      const pulse = Math.sin(frame * 0.04 + (n.id.length)) * 4;
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 16 + pulse, 0, Math.PI * 2);
      ctx.strokeStyle = `${n.color}22`;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Core node circle
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 12, 0, Math.PI * 2);
      ctx.fillStyle = '#0f172a';
      ctx.strokeStyle = n.color;
      ctx.lineWidth = 2;
      ctx.fill();
      ctx.stroke();

      // Inner dot
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = n.color;
      ctx.fill();

      // Node label
      ctx.font = '600 10px "JetBrains Mono", monospace';
      ctx.fillStyle = '#94a3b8';
      ctx.textAlign = 'center';
      ctx.fillText(n.label, pos.x, pos.y + 26);
    });

    requestAnimationFrame(render);
  }

  requestAnimationFrame(render);
})();
