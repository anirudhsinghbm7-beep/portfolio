/* ==========================================================================
   FLUID WATER MOTION SIMULATION
   Sinusoidal wave interference & ripple physics for the Swimming section
   ========================================================================== */

(function () {
  const canvas = document.getElementById('water-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const parent = canvas.parentElement;

  let width, height;
  let phase = 0;
  let mouseRipple = { x: -100, y: -100, strength: 0 };

  function resize() {
    if (!parent) return;
    width = canvas.width = parent.clientWidth;
    height = canvas.height = parent.clientHeight;
  }

  window.addEventListener('resize', resize);
  setTimeout(resize, 120);

  parent.addEventListener('mousemove', (e) => {
    const rect = parent.getBoundingClientRect();
    mouseRipple.x = e.clientX - rect.left;
    mouseRipple.y = e.clientY - rect.top;
    mouseRipple.strength = 1.0;
  });

  parent.addEventListener('mouseleave', () => {
    mouseRipple.strength = 0;
  });

  function render() {
    if (!width || !height) {
      requestAnimationFrame(render);
      return;
    }

    ctx.clearRect(0, 0, width, height);
    phase += 0.015;

    // Decay ripple strength
    if (mouseRipple.strength > 0.01) {
      mouseRipple.strength *= 0.96;
    }

    const waves = [
      { amp: 14, freq: 0.012, speed: 1.0, color: 'rgba(56, 189, 248, 0.06)' },
      { amp: 20, freq: 0.008, speed: 1.4, color: 'rgba(14, 165, 233, 0.08)' },
      { amp: 10, freq: 0.016, speed: 0.8, color: 'rgba(6, 182, 212, 0.05)' }
    ];

    waves.forEach((w) => {
      ctx.beginPath();
      ctx.moveTo(0, height);

      for (let x = 0; x <= width; x += 6) {
        let baseWave = Math.sin(x * w.freq + phase * w.speed) * w.amp;

        // Interaction distortion near mouse
        const distToMouse = Math.abs(x - mouseRipple.x);
        if (distToMouse < 180 && mouseRipple.strength > 0) {
          const factor = (1 - distToMouse / 180) * mouseRipple.strength;
          baseWave += Math.sin(distToMouse * 0.05 - phase * 3) * 16 * factor;
        }

        const y = height * 0.55 + baseWave;
        ctx.lineTo(x, y);
      }

      ctx.lineTo(width, height);
      ctx.closePath();
      ctx.fillStyle = w.color;
      ctx.fill();
    });

    requestAnimationFrame(render);
  }

  requestAnimationFrame(render);
})();
